#ofxRPiTouch
Addon for using the RaspberryPi 7" Touch Dipsplay [WIP]

![alt text][logo]

[logo]: https://github.com/apparentVJ/ofxRPiTouch/blob/master/image.jpg

* Position
* Button
* TouchCount
* absPosition
* absTrackingID

Provides an interface with: struct *input_event ev;*
Heavily inspired from kashimAstro's [ofxTFTTouch](https://github.com/kashimAstro/ofxTFTTouch)
